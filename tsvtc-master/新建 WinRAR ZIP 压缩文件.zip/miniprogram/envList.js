const envList = [{"envId":"cloud1-0g13eflhd9a55d69","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}